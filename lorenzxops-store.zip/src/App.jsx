import React, { useState, useEffect } from 'react';

export default function App() {
  const [products, setProducts] = useState([
    { id: 1, name: 'منتج تجريبي', description: 'وصف المنتج', price: 99.99 },
  ]);
  const [orders, setOrders] = useState([]);

  const placeOrder = (product) => {
    const newOrder = {
      id: Date.now(),
      product,
      date: new Date().toLocaleString(),
    };
    const updatedOrders = [...orders, newOrder];
    localStorage.setItem('orders', JSON.stringify(updatedOrders));
    setOrders(updatedOrders);
    alert('تم الطلب بنجاح!');
  };

  useEffect(() => {
    const savedOrders = JSON.parse(localStorage.getItem('orders')) || [];
    setOrders(savedOrders);
  }, []);

  return (
    <div style={{ padding: 20 }}>
      <h1>متجر Lorenz X Ops</h1>
      {products.map((product) => (
        <div key={product.id} style={{ border: '1px solid #ccc', padding: 10, marginBottom: 10 }}>
          <h3>{product.name}</h3>
          <p>{product.description}</p>
          <p>السعر: ${product.price}</p>
          <button onClick={() => placeOrder(product)}>اطلب الآن</button>
        </div>
      ))}
      <hr />
      <h2>الطلبات</h2>
      {orders.map((order) => (
        <div key={order.id}>
          <p>المنتج: {order.product.name}</p>
          <p>التاريخ: {order.date}</p>
        </div>
      ))}
    </div>
  );
}